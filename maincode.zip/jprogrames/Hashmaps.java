import java.util.*;
class Hashmaps{
    public static void main(String[] args) {
        HashMap<Integer,String> hmap = new HashMap<>();
        hmap.put(1, "java");
        hmap.put(2, "py");
        hmap.put(3, "c++");
        System.out.println(hmap);
        System.out.println("Read Data");
        for(Map.Entry<Integer,String>entry: hmap.entrySet()){
            System.out.println(entry.getKey()+ "-->" +entry.getValue());

        }
        hmap.put(2,"C");
        System.out.println("After update(key=2): " +hmap.get(2));

        hmap.remove(2);
        System.out.println("After deletion: " +hmap);
    }
}