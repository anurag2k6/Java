
import java.util.Scanner;

class Strings{
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String name = s.nextLine();
        System.out.println(s.length());
        System.out.println(s.toUppercase());
        System.out.println(s.toLowercase());

    }
}