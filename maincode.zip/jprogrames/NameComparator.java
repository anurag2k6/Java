import java.util.*;
class NameComparator{
    public int compare(Studentinfo s1,Studentinfo s2) {
        return s1.name.compareTo(s2.name);
    }
}