import mathpack.Ex;
public class Main{
    public static void main(String[] args) {
        Ex e = new Ex();
        System.out.println("Addition: " +e.add(5,10));
        System.out.println("Multipication: " +e.mul(5,5));

    }
}
