class Buffer{
    int data;
    boolean availble = false;
    synchronized void produce(int value) throws InterruptedException {
       if(availble)
       {
              wait();

       }
       data = values;
         System.out.println("Produced: " + data);
         availble = true;
         notify();
    }
    synchronized void consume() throws InterruptedException {
        if(!availble)
        {
            wait();
        }
        System.out.println("Consumed: " + data);
        availble = false;
        notify();
    }
    
}