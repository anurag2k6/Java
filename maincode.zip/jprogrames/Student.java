import java.util.*;
class Student implements Comparable<Student>{
    int id;
    String name;
    Student(int id ,String name){
        this.id = id;
        this.name = name;
    }
    public int compareTo(Student s){
        return this.id - s.id;
    }
    public static void main(String[] args) {
        ArrayList<Student> li = new ArrayList<>();
        li.add(new Student(3,"ram"));
        li.add(new Student(1,"jam"));
        li.add(new Student(2,"nam"));
        for(Student s : li){
            
        }
        System.out.println(li.id + " " + li.name);
    }

}