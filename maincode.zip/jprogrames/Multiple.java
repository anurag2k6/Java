/*class Multiple{
    public static void main(String[] args){
        try{
            int a[] = new int[5];
            a[10] = 50;
            int x = 10/0;
        }
        catch(ArithmeticException e){
            System.out.println("cannot divide by zero");
        }
        catch(ArrayIndexOutOfBoundsException e){
            System.out.println("array index out of bounds Exception");
        }
           
            finally{
                System.out.println("finally block is excuted");
            }
    }
}*/
