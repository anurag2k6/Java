import java.util.*;
class Tree{
    public static void main(String[] args) {
        TreeMap<Integer,String> tmap = new TreeMap<>();
        tmap.put(1, "java");
        tmap.put(2, "py");
        tmap.put(3, "c++");
        System.out.println(tmap);
        System.out.println("Read Data");
        for(Map.Entry<Integer,String>entry: tmap.entrySet()){
            System.out.println(entry.getKey()+ "-->" +entry.getValue());

        }
        tmap.put(2,"C");
        System.out.println("After update(key=2): " +tmap.get(2));

        tmap.remove(2);
        System.out.println("After deletion: " +tmap);
    }
}