import java.util.*;
class Iteration{
    public static void main(String[] args) {
        ArrayList<Integer> li = new ArrayList<>();
        li.add(10);
        li.add(20);
        li.add(30);
        for(int n : li){
            System.out.println(n);
        }
    }
}