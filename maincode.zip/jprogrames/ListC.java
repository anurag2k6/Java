import java.util.*;
class ListC{
    public static void main(String[] args) {
        //Scanner scan = new Scanner(System.in);
        //int num = scan.nextInt();
        LinkedList<Integer> li = new LinkedList<>();
        //ArrayList<Integer> li = new ArrayList<>();
        li.add(10);
        li.add(20);
        li.add(30);
        li.add(40);
        li.add(50);
        li.add(60);
        li.add(70);
        System.out.println(li);

        System.out.println("read operation: " +li.get(5));

        li.set(4,80);
        li.set(2,200);
        System.out.println("set operation: " +li);

        li.remove(1);
        System.out.println("delete operation: " +li);
        //li.getFirst();
        System.out.println("after getFirst : " +li.getFirst());
        System.out.println("after getLast : " +li.getLast());
        System.out.println("after removeFirst : " +li.removeFirst());
        System.out.println("after removelast : " +li.removeLast());
        System.out.println("final: " +li);
    }
}