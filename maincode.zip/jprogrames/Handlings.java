class Handlings {
    public static void main(String[] args) {
        try{
            int a = 10/0;
        
        }
        catch(ArithmeticException e){
            System.out.println("cannot divide by zero");
        }
        finally{
            System.out.println("finally keword is excuted");
        }

    } 
}