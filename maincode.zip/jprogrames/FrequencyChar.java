public class FrequencyChar {
    public static void main(String[] args) {
        String str = "aabbccc";

        int max = 0;
        char result = ' ';

        for (int i = 0; i < str.length(); i++) {
            int count = 1;

            for (int j = i + 1; j < str.length(); j++) {
                if (str.charAt(i) == str.charAt(j)) {
                    count++;
                }
            }

            if (count > max) {
                max = count;
                result = str.charAt(i);
            }
        }

        System.out.println("Most frequent: " + result);
    }
}