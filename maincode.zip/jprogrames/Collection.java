import java.util.*;
class Collection{
    public static void main(String[] args){
        List<String> li = new ArrayList<>();
        li.add("C");
        li.add("c++");
        li.add("java");
        System.out.println(li);
    }
}