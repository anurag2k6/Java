import java.io.*;
class EvenOddfile{
    public static void main(String[] args) throws IOException {
        int num[] = {1,2,3,4,5,6,7,8,9};
        FileWriter evenWriter = new FileWriter("Even.txt");
        FileWriter oddWriter = new FileWriter("Odd.txt");
        for(int n: num)
        {
            if(n%2==0)
            {
                evenWriter.write(n+ "\n");
            }
            {
                oddWriter.write(n+ "\n");
            }
        }
        evenWriter.close();
        oddWriter.close();
    }
}