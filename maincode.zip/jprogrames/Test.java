class InvalidAgeException extends Exception {
    public InvalidAgeException(String message) {
        super(message);
    }

}
class Test {
    public static void main(String[] args) {
        int age = 15;
        try {
            if (age < 18) {
                throw new InvalidAgeException("not valid");
            }
            System.out.println("welcome to vote");
        } catch (InvalidAgeException e) {
            System.out.println(e.getMessage());
        }
    }
}
}