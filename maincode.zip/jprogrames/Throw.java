class Throw {
    public static void main(String[] args){
        int age = 15;
        if(age < 18){
            throw new ArithmeticException("not valid");
        }
        System.out.println("welcome to vote");
    }
}