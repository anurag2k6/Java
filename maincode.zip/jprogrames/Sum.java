import java.util.*;
class Sum{
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int last_digit = n%10;
        int first_digit = n;
        while(first_digit  >10){
            first_digit = first_digit/10;
        }
        int sum = first_digit + last_digit;
        System.out.println(sum);
        

    }
}