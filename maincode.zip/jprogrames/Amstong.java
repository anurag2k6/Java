import java.util.Scanner;

class Amstong {                           // Opening brace 1
    public static void main(String[] args) {  // Opening brace 2
        Scanner sc = new Scanner(System.in);
        int original = sc.nextInt();
        int num = original;
        int sum = 0;
        int digits = String.valueOf(original).length();
        
        while(num > 0) {                  // Opening brace 3
            int digit = num % 10;
            sum += Math.pow(digit, digits);
            num /= 10;
        }                                 
        
        if(sum == original) {            
            System.out.println(original + ": is an Armstrong number");
        } else {                          
            System.out.println(original + ": is not an Armstrong number");
        }                                 
        
        sc.close();
    }                                     
}                                         
