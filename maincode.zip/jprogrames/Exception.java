import java.util.*;
class Exception {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();
        int b = scan.nextInt();
        try{
            int c = a/b;
            System.out.println(c);
        }catch(ArithmeticException e){
            System.out.println("cannot divide by zero");
        }
        System.out.println("Programm continues...");
    }
}