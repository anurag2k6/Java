package mathpack;
public class Ex{
    public int add(int a, int b){
        return a+b;
    }
    public int mul(int a, int b){
        return a*b;
    }

}