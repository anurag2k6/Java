import java.util.*;

class StudentDriver {
    public static void main(String[] args) {
        ArrayList<Studentinfo> li = new ArrayList<>();

        li.add(new Studentinfo(1,"ram"));
        li.add(new Studentinfo(3,"arun"));
        li.add(new Studentinfo(2,"krishna"));

        Collections.sort(li ,new NameComparator());

        System.out.println(li);
    }
}