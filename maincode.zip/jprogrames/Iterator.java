import java.util.*;
class Itarator{
    public static void main(String[] args) {
        ArrayList<Integer> li = new ArrayList<>();
        li.add(1);
        li.add(2);
        li.add(3);
        Itarator<Integer> itr = li.iterator();
        while(itr.hasNext()){
            int num = itr.next();
            if(num == 2){
                itr.remove();
            }
        }
        System.out.println(li);
    }
}