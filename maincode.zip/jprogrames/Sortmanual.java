class Sortmanual
{
    public static void main(String[] args) {
        int arr[]={2,7,6,8,3,4};
        for(int i=0; i<arr.length; i++)
        {
            for(int j=i+1;j<arr.length;j++)
            {
                if(arr[i]>arr[j])
                {
                    int temp=arr[i];
                    arr[i]=arr[j];
                    arr[j]=temp;
                }
            }
        }
        System.err.println("sorted Array:");
        for(int num:arr)
        {
            System.err.println(num+ "");
        }
    }
}