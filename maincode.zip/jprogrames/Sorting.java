import java.util.*;
class Sorting{
    public static void main(String[] args) {
        int arr[]={2, 6 , 8 ,6 ,7};
        System.out.println("original Array: " + Arrays.toString(arr));
        Arrays.sort(arr);
        System.out.println("sorted array: " + Arrays.toString(arr));
    }
}