import java.util.*;
class Studentinfo{
    int id;
    String name;

    public Studentinfo(int id,String name) {
        this.id = id;
        this.name = name;
    }
    public String toString(){
        return id+ " " +name;
    }
    
}
//main 16,sub 14,content 12,typesnuroman